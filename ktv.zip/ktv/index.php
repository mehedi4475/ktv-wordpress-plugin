<?php
/**
 * Plugin Name: KTV Plugin.
 * Plugin URI: http://ktvbd.com
 * Version: 1.0.0
 * Author: Krishibid Group
 * Author URI: http://krishibidgroup.org.bd
 * License: A short license name. Example: GPL2
 */

?>


<?php

class ktv extends WP_Widget {

	function ktv() {
		// Instantiate the parent object
		parent::__construct( false, 'KTV Live' );
	}

	function widget( $args, $instance ) {
    ?>
<p>
<div class="widget widget_categories">
      <a href='http://ktvbd.com' target="_blank"><h4 class="widgettitle">KTV</h4> </a>

            <video autoplay="" class="video-js vjs-default-skin" controls="" data-setup="{ &quot;plugins&quot;: {  } }" height="200px" id="example_video_1" poster="videojs/poster.png" preload="auto" width="250px"><source src="rtmp://119.81.23.66:1935/live/1234" type="rtmp/mp4" />
        <p class="vjs-no-js">To view this video please enable JavaScript, and consider upgrading to a web browser that <a href="http://videojs.com/html5-video-support/" target="_blank">supports HTML5 video</a></p>
        </video>
</div>

<p>
    <?php		
	}

	function update( $new_instance, $old_instance ) {
		// Save widget options
	}

	function form( $instance ) {
		// Output admin widget options form
	}
}

function myplugin_register_widgets() {
	register_widget( 'ktv' );
}

add_action( 'widgets_init', 'myplugin_register_widgets' );






?>




<?php

//Add style
function theme_enqueue_styles() {
    wp_enqueue_style( 'video-js', plugin_dir_url( __FILE__ )  . 'css/video-js.css','','');
    wp_enqueue_style( 'videojs.watermark', plugin_dir_url( __FILE__ )  . 'css/videojs.watermark.css','','');
    

}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );

//Add scripts 
function theme_name_scripts() {
	wp_enqueue_script( 'video', plugin_dir_url( __FILE__ ) . 'js/video.js', array('jquery'), '', true );	
	wp_enqueue_script( 'videojs-playlists', plugin_dir_url( __FILE__ ) . 'js/videojs-playlists.js', array('jquery'), '', true );	
	
}
add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );

?>

